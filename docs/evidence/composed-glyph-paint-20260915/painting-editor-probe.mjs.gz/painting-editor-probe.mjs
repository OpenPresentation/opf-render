import {readFile,writeFile} from 'node:fs/promises';
import {build} from 'esbuild';
import {chromium} from 'playwright';
import {prepareNodeFonts} from '../../dist/fonts-node.js';
import {loadHarfBuzzShaper} from '../../dist/font-shaping.js';
const prepared=await prepareNodeFonts({pack:'office',fontShaper:await loadHarfBuzzShaper()});
const family=process.env.OPF_EDITOR_PROBE_FAMILY??'Arimo';
const faces=prepared.registry.embeddedFonts.filter(f=>f.family===family);
const bundle=await build({stdin:{contents:"import {createCanvasEditor} from '/Users/michael/Source/opf-editor/dist/canvas.js';import {createEditorSession} from '/Users/michael/Source/opf-editor/dist/index.js';import {loadBrowserFontRegistry} from '@openpresentation/opf-render/fonts-browser';import {loadHarfBuzzShaper} from '@openpresentation/opf-render/font-shaping-browser';globalThis.probe={createCanvasEditor,createEditorSession,loadBrowserFontRegistry,loadHarfBuzzShaper};",resolveDir:process.cwd()},bundle:true,platform:'browser',format:'esm',write:false});
const wasm=await readFile(new URL(import.meta.resolve('@openpresentation/opf-render/harfbuzz.wasm')));
const browser=await chromium.launch();const report={node:process.version,browser:browser.version(),errors:[]};
try {
 const page=await browser.newPage({viewport:{width:1400,height:950}});page.on('pageerror',e=>report.errors.push(e.message));
 await page.route('**/*',route=>{const url=new URL(route.request().url());if(url.origin!=='https://opf-editor-paint.test')return route.abort();if(url.pathname==='/harfbuzz.wasm')return route.fulfill({contentType:'application/wasm',body:wasm});if(url.pathname==='/bundle.js')return route.fulfill({contentType:'text/javascript',body:Buffer.from(bundle.outputFiles[0].contents)});return route.fulfill({contentType:'text/html',body:'<style>body{margin:0}#host{width:1280px}</style><div id="host"></div><script type="module" src="/bundle.js"></script>'});});
 await page.goto('https://opf-editor-paint.test/');await page.waitForFunction(()=>!!globalThis.probe);
 report.family=family;report.initial=await page.evaluate(async({faces,family})=>{
  const registry=await probe.loadBrowserFontRegistry(faces.map(f=>({...f,data:Uint8Array.from(atob(f.dataUrl.split(',')[1]),c=>c.charCodeAt(0))})),{fontShaper:await probe.loadHarfBuzzShaper()});
  const text='AVATAR office affine o\u0302\u0301';const original={name:'Retain metadata',design:{fontScheme:{id:'roboto',heading:{family},body:{family},code:{family}}},slides:[{text:[{text,fontFamily:family,fontSize:24,underline:true,link:'https://example.com'}],notes:'Retain notes'}]};
  const editor=probe.createEditorSession(original,{rejectInvalid:true}),errors=[];
  const canvas=probe.createCanvasEditor(document.querySelector('#host'),{editor,renderOptions:{textMeasurement:registry.textMeasurement,textPainting:registry.textPainting,embeddedFonts:registry.embeddedFonts},onError:e=>errors.push(e.message)});await canvas.ready;canvas.beginEdit('slides.0.text');
  const input=document.querySelector('.opf-rich-input'),target=document.querySelector('.opf-canvas-preview [data-opf-path="slides.0.text"]');
  const run=registry.textPainting.shape(text,{fontFamily:family,fontWeight:400});const paths=[...target.querySelectorAll('path[data-opf-glyph-source-start]')];const points=[];
  for(const glyph of run.glyphs){if(glyph.xOffset||points.some(p=>p.offset===glyph.sourceStart))continue;const path=paths.find(p=>Number(p.dataset.opfGlyphSourceStart)===glyph.sourceStart);if(!path)throw Error('Missing traced paint glyph');input.setSelectionRange(glyph.sourceStart,glyph.sourceStart);input.dispatchEvent(new Event('select'));const caret=document.querySelector('.opf-rich-caret').getBoundingClientRect(),expected=path.getScreenCTM().e;points.push({offset:glyph.sourceStart,paintOrigin:expected,caret:caret.left,difference:caret.left-expected});}
  globalThis.editorState={editor,canvas,registry,original,errors};input.setSelectionRange(text.length,text.length);input.dispatchEvent(new Event('select'));
  return {points,maxCaretDifference:Math.max(...points.map(p=>Math.abs(p.difference))),sourceBefore:JSON.stringify(editor.document)===JSON.stringify(original),errors};
 },{faces,family});
 await page.locator('.opf-rich-input').pressSequentially(' added');
 report.edit=await page.evaluate(()=>{const {editor,canvas,original,errors}=editorState;const unchangedUntilCommit=JSON.stringify(editor.document)===JSON.stringify(original);const commit=canvas.commit();const changed=structuredClone(editor.document);editor.undo();const undo=JSON.stringify(editor.document)===JSON.stringify(original);canvas.destroy();editorState.registry.dispose();return {unchangedUntilCommit,commit,changed,undo,errors};});
} catch(error){report.failure=error.stack;throw error;}finally{prepared.registry.dispose();await browser.close();await writeFile(new URL(`./painting-editor-probe-${family}.json`,import.meta.url),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify(report,null,2));
