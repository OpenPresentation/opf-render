import {fontFixtures,instanceCases} from '../../../test/font-variations-fixtures.mjs';
import {create} from 'fontkit';
import * as hb from 'harfbuzzjs';
import {writeFile} from 'node:fs/promises';
const round=n=>Math.sign(n)*Math.floor(Math.abs(n)+.5),fixed=n=>Math.floor(n*65536+.5),clamp=n=>Math.max(-65536,Math.min(65536,n));
function normalized(font,values){
 return font.fvar.axis.map((axis,i)=>{
  const v=fixed(values[axis.axisTag]),min=fixed(axis.minValue),def=fixed(axis.defaultValue),max=fixed(axis.maxValue);
  let n=v===def?0:clamp(round((v-def)*65536/(v<def?def-min:max-def)));
  const pairs=font.avar?.segment[i]?.correspondence??[];
  for(let j=0;j<pairs.length;j++){
   const end=pairs[j],e=fixed(end.fromCoord);
   if(e===n){n=fixed(end.toCoord);break;}
   if(e>n&&j){const start=pairs[j-1],s=fixed(start.fromCoord),ratio=round((n-s)*65536/(e-s));n=clamp(fixed(start.toCoord)+round(ratio*(fixed(end.toCoord)-fixed(start.toCoord))/65536));break;}
  }
  return Math.floor((n+2)/4)/16384;
 });
}
const result={node:process.version,harfbuzz:hb.versionString(),cases:[],totals:{original:0,finalOnly:0,fixed:0}};
for(const record of (await fontFixtures()).filter(r=>r.outline==='CFF2')){
 const base=create(record.data),blob=new hb.Blob(record.data.buffer.slice(record.data.byteOffset,record.data.byteOffset+record.data.byteLength)),face=new hb.Face(blob),font=new hb.Font(face);font.setScale(face.upem,face.upem);
 for(const item of instanceCases(record)){
  const varied=base.getVariation(item.coordinates),p=varied._variationProcessor,original=[...p.normalizedCoords],end=original.map(v=>Math.floor(v*16384+.5)/16384),norm=normalized(base,item.coordinates);
  const row={file:record.file,id:item.id,coordinates:item.coordinates,original,finalOnly:end,fixed:norm,differences:{original:[],finalOnly:[],fixed:[]}};
  font.setVariations(Object.entries(item.coordinates).map(([k,v])=>new hb.Variation(k,v)));
  for(const [policy,coords] of Object.entries({original,finalOnly:end,fixed:norm})){
   p.normalizedCoords=coords;p.blendVectors.clear();
   for(let gid=0;gid<base.numGlyphs;gid++){
    const advance=base.hmtx.metrics.get(Math.min(gid,base.hmtx.metrics.length-1)).advance,delta=p.getAdvanceAdjustment(gid,base.HVAR),calculated=Math.max(0,advance+round(delta)),actual=font.glyphHAdvance(gid);
    if(calculated!==actual){result.totals[policy]++;row.differences[policy].push({gid,delta,calculated,actual});}
   }
  }
  result.cases.push(row);
 }
}
await writeFile('artifacts/font-shaping/variation-metrics/normalization-probe.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({cases:result.cases.length,totals:result.totals}));
