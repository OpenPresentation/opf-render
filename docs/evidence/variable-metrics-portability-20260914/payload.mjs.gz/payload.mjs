import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync} from 'node:zlib';
import {build} from 'esbuild';
const evidence=JSON.parse(gunzipSync(await readFile('docs/evidence/dfont-resources-20260914/installed.json.gz')));
const old=evidence.consumer,current=process.cwd(),hash=b=>createHash('sha256').update(b).digest('hex');
for(const [file,expected]of Object.entries(evidence.files))assert.equal(hash(await readFile(old+'/node_modules/@openpresentation/opf-render/'+file)),expected,'Verify prior package '+file);
const rows=[];
for(const entry of ['fonts-browser','svg'])for(const [label,resolveDir]of [['prior-dfont',old],['current-variable',current]]){
 const output=await build({stdin:{contents:`import * as api from '@openpresentation/opf-render/${entry}'; globalThis.opfApi=api;`,resolveDir},bundle:true,platform:'browser',format:'esm',target:'es2022',minify:true,write:false,metafile:true});
 const bytes=output.outputFiles[0].contents;
 rows.push({label,entry,bytes:bytes.length,gzipBytes:gzipSync(bytes,{level:9}).length,sha256:hash(bytes),wasmInBundle:new TextDecoder().decode(bytes).includes('harfbuzz.wasm'),codecs:Object.keys(output.metafile.inputs).filter(p=>/font-woff|font-preparation|font-variations/.test(p))});
}
await writeFile('artifacts/font-shaping/variation-metrics/payload.json',JSON.stringify({priorConsumer:old,priorFileHashesVerified:Object.keys(evidence.files).length,rows},null,2)+'\n');console.log(JSON.stringify(rows));
