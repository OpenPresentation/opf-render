import {readFile,writeFile} from 'node:fs/promises';
import {create} from 'fontkit';
import * as hb from 'harfbuzzjs';
const previous=JSON.parse(await readFile('artifacts/font-shaping/variations-browser.json'));
const rows=previous.observations.filter(r=>['otf','ttf'].includes(r.format));
const text='  office affine AVATAR  ',out=[];
for(const row of rows){
 const data=await readFile('test/fixtures/font-formats/'+row.file);
 const base=create(data),fk=Object.keys(row.coordinates).length?base.getVariation(row.coordinates):base;
 const run=fk.layout(text),blob=new hb.Blob(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength)),face=new hb.Face(blob),font=new hb.Font(face);
 font.setVariations(Object.entries(row.coordinates).map(([k,v])=>new hb.Variation(k,v)));
 const scales=[];
 for(const factor of [1,64,1024]){
  font.setScale(face.upem*factor,face.upem*factor);const b=new hb.Buffer();b.addText(text);b.setLanguage('und');b.guessSegmentProperties();hb.shape(font,b);
  const p=b.getGlyphPositions();scales.push({factor,width:p.reduce((n,p)=>n+p.xAdvance,0)/factor/face.upem*32,positions:p.map(p=>p.xAdvance/factor)});
 }
 const rounded=run.positions.reduce((n,p,i)=>n+p.xAdvance+Math.round(run.glyphs[i].advanceWidth)-run.glyphs[i].advanceWidth,0)/face.upem*32;
 out.push({...row,scales,fontkit:run.advanceWidth/face.upem*32,fontkitRoundedGlyph:rounded});
}
await writeFile('artifacts/font-shaping/variation-metrics/probe.json',JSON.stringify(out,null,2)+'\n');
for(const format of ['otf','ttf']){
 const subset=out.filter(r=>r.format===format&&r.backend==='harfbuzz');
 console.log(JSON.stringify({format,cases:subset.length,rawMax:Math.max(...subset.map(r=>Math.abs(r.fontkit-r.snapshots[0].advance))),roundGlyphMax:Math.max(...subset.map(r=>Math.abs(r.fontkitRoundedGlyph-r.snapshots[0].advance))),hbScales:[1,64,1024].map(factor=>({factor,max:Math.max(...subset.map(r=>Math.abs(r.scales.find(s=>s.factor===factor).width-r.snapshots[0].advance)))}))}));
}
